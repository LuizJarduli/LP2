﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace P30482011021
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            //RA : 0030482011021
            lbxDados.Items.Clear();
            int digitoLinha = 1;
            int coluna = 4;
            double[,] matriz = new double[digitoLinha, coluna];
            double[] TotalPorSemana = new double[digitoLinha];
            double TotalGeral = 0;

            for (var i = 0; i < digitoLinha; i++)
            {
                TotalPorSemana[i] = 0;
                for (var j = 0; j < coluna; j++)
                {
                    if (double.TryParse(Interaction.InputBox($"Total do mês {i + 1} , Semana {j + 1}: ", "Entrada de dados"), out matriz[i, j]))
                    {
                        TotalPorSemana[i] += matriz[i, j];
                    }
                    else
                    {
                        MessageBox.Show("Insira Valores Númericos por favor!");
                    }
                }
                TotalGeral += TotalPorSemana[i];
            }
            for (int i = 0; i < digitoLinha; i++)
            {
                for(int j = 0; j < coluna; j++)
                {
                    lbxDados.Items.Add($"Total do mês {i+1}, Semana {j + 1}: {matriz[i,j].ToString("c2")}\n");
                }
                lbxDados.Items.Add($"\n>> Total do mês {i+1}: {TotalPorSemana[i].ToString("c2")}");
                lbxDados.Items.Add("---------------------");
            }
            lbxDados.Items.Add($"\n>> Total Geral : {TotalGeral.ToString("c2")}");

        }
    }
}
